
import time
import importlib

def get_engine_module():
    engine_module = importlib.import_module(".myscelium_engine", package="myscelium")
    return engine_module

class MysceliumHost:

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MysceliumHost, cls).__new__(cls)
        return cls._instance

    def __init__(self, callbacks:list=None, host_id:int=None, allowed_clients:list=None, buffer_path:str=None, n_workers=2, n_max_conns:int=5):

        if hasattr(self, 'initialized') and self.initialized:
            # If we've already initialized the instance before, skip further initialization
            return

        self.allowed_clients = allowed_clients
        self.host_id = host_id
        special_functions = [{
            "function": self.get_registred_commands,
            "response_type": "same_as_origin",
            "args": "None",
        }]
        
        if callbacks is None:
            callbacks = []
            
        callbacks = callbacks + special_functions

        engine_module = get_engine_module()
        engine_module.registry_socket_host_callbacks(callbacks)
        engine_module.initalize_host_buffer_tables(buffer_path)
        engine_module.set_socket_host_allowed_clients(self.allowed_clients)
        engine_module.set_socket_host_transposer_num_of_workers(n_workers)
        engine_module.set_socket_host_max_connections(n_max_conns)

        self.host_thread = None
        
        # Mark this instance as initialized
        self.initialized = True

    def set_client_heartbeat_handler(self, callback):
        engine_module = get_engine_module()
        engine_module.registry_socket_host_client_heartbeat_contact_callback(callback)
    
    def get_registred_commands(self) -> dict:
        engine_module = get_engine_module()
        print("Activated the get registred commands")
        return engine_module.get_socket_host_available_commands()

    def initialize_host(self, ip:str, port:int):
        engine_module = get_engine_module()
        engine_module.initialize_socket_host(ip, port, self.host_id)

    def stop_host(self, signal, frame):
        engine_module = get_engine_module()
        engine_module.stop_socket_host()

    def send(self):
        pass
    
class HostPatterns:

    def __init__(self) -> None:
        pass

    def client_pattern (self, client_type:str, client_id:str) -> dict:
        return {"client_type":client_type, "client_id":client_id}

    def response_pattern (self, response:any, response_mode:str, response_activation_function:str = None,  redirect_to_client_id:str=None) -> dict:

        if response_activation_function == "" or response_activation_function == None:
            raise ("Missing response_activation_function!")

        if response_mode == "redirect":

            if redirect_to_client_id != None:
                pass
            else:
                raise ("Invalid redirect! Missing client_id to redirect!")

            return {'response_mode':'redirect', 'response_activation_function':response_activation_function, 'response':response, 'redirect_to':redirect_to_client_id}

        elif response_mode == 'to_origin':

            print("Response mode set to origin")
            
            return {'response_mode':'to_origin', 'response_activation_function':response_activation_function, 'response':response}
        
        else:
            raise ("Response mode invalid! Please use one of this: ('redirect', 'to_origin')")

    def callback_pattern (self, callback, args) -> dict:
            
            callback_pattern =  {
                "function": callback,
                "args": args,
            }
            
            return callback_pattern

class MysceliumClient:

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MysceliumClient, cls).__new__(cls)
        return cls._instance

    def __init__(self, client_uid:int=None, buffer_path:str=None, n_workers=2):

        # Check if already initialized
        if hasattr(self, 'initialized') and self.initialized:
            return

        self.client_uid = client_uid
        self.running = False

        special_functions = [{
            "function": self.get_registred_commands,
            "response_type": "same_as_origin",
            "args": "None",
        }]

        engine_module = get_engine_module()
        engine_module.initalize_client_buffer_tables(buffer_path)
        engine_module.set_socket_client_transposer_num_of_workers(n_workers)

        self.host_thread = None
        
        # Mark this instance as initialized
        self.initialized = True

    def set_client_uid(self, client_uid):
        engine_module = get_engine_module()
        engine_module.set_client_uid(client_uid)

    def set_workers_num(self, n_workers=2):
        engine_module = get_engine_module()
        engine_module.set_socket_client_transposer_num_of_workers(n_workers)

    def set_callbacks(self, callbacks:list):
        engine_module = get_engine_module()

        if callbacks is None:
            callbacks = []

        special_functions = [{
            "function": self.get_registred_commands,
            "response_type": "same_as_origin",
            "args": "None",
        }]
        
        callbacks = callbacks + special_functions
        engine_module.registry_socket_client_callbacks(callbacks)

    def get_registred_commands(self) -> dict:
        engine_module = get_engine_module()
        print("Activated the get registred commands")
        return engine_module.get_socket_client_available_commands()

    def initialize_client(self, ip:str, port:int):
        engine_module = get_engine_module()
        self.running = True
        engine_module.initialize_socket_client(ip, port, self.client_uid)

    def stop_client(self, signal, frame):
        engine_module = get_engine_module()
        engine_module.stop_socket_client()

    def send(self, command:dict, priority:int):
        engine_module = get_engine_module()
        if not self.running:
            raise Exception("Client needs to be running before attempting to send something")
        return engine_module.client_send(command, priority)
        
class ClientPatterns:

    def __init__(self) -> None:
        pass

    def client_pattern (self, client_type:str, client_id:str) -> dict:
        return {"client_type":client_type, "client_id":client_id}

    def command_pattern (self, command_function:str, args=None):

        if args != None:
            return {"function":command_function, "args":args}
        else:
            pass

        return {"function":command_function, "args":""}

    def response_pattern (self, response:any, response_mode:str, retransmit_to_client_id:str=None) -> dict:

        if response_mode == "retransmit":

            if retransmit_to_client_id != None:
                pass
            else:
                raise ("Invalid redirect! Missing client_id to redirect!")

            return {'response_mode':'retransmit', 'response':response, 'redirect_to':retransmit_to_client_id}

        elif response_mode == 'to_host':
            
            return {'response_mode':'to_host', 'response':response}
        
        else:
            raise ("Response mode invalid! Please use one of this: ('redirect', 'same_as_origin')")

    def callback_pattern (self, callback, args) -> dict:
            
            callback_pattern =  {
                "function": callback,
                "args": args,
            }
            
            return callback_pattern

# -> Functions:

host_patterns = HostPatterns()

def get_registred_commands () -> dict:
    print("Activated the get registred commands")
    response = engine_module.get_socket_host_available_commands()

    print(f"\nAvaliable commands:\n{response}\n")

    response = host_patterns.response_pattern(response=response, response_activation_function='update_avaliable_host_commands',  response_mode='to_origin')

    print(f"Response to return to rust myscelium engine: {response}")

    return response


